<?php
/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2026 EspoCRM, Inc.
 *
 * License ID: 11af5a568c1a72dce4e164257d1a0207
 ************************************************************************************/

namespace Espo\Modules\Sales\Tools\PaymentTermsProfile;

use Espo\Modules\Sales\Entities\PaymentTermsProfile;
use Espo\Modules\Sales\Tools\Sales\ConfigDataProvider;
use Espo\ORM\EntityManager;

class DefaultPaymentTermsProfileProvider
{
    private ?PaymentTermsProfile $entity = null;
    private bool $isCached = false;

    public function __construct(
        private ConfigDataProvider $configDataProvider,
        private EntityManager $entityManager,
    ) {}

    public function get(): ?PaymentTermsProfile
    {
        $id = $this->configDataProvider->getDefaultPaymentTermsProfileId();

        if (!$id) {
            return null;
        }

        if (!$this->isCached) {
            $entity = $this->entityManager->getRDBRepositoryByClass(PaymentTermsProfile::class)->getById($id);

            $this->isCached = true;

            if ($entity->isActive()) {
                $this->entity = $entity;
            }
        }

        return $this->entity;
    }
}
