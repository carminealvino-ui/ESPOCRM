<?php
/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2026 EspoCRM, Inc.
 *
 * License ID: 11af5a568c1a72dce4e164257d1a0207
 ************************************************************************************/

namespace Espo\Modules\Sales\Tools\PaymentTerms\Api;

use Espo\Core\Acl;
use Espo\Core\Api\Action;
use Espo\Core\Api\Request;
use Espo\Core\Api\Response;
use Espo\Core\Api\ResponseComposer;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;
use Espo\Core\Exceptions\NotFound;
use Espo\Core\Record\SearchParamsFetcher;
use Espo\Modules\Sales\Entities\Invoice;
use Espo\Modules\Sales\Tools\PaymentTerms\InvoiceInstallmentRecordService;
use Espo\ORM\EntityManager;

/**
 * @noinspection PhpUnused
 */
class GetInvoiceInstallments implements Action
{
    public function __construct(
        private EntityManager $entityManager,
        private Acl $acl,
        private SearchParamsFetcher $searchParamsFetcher,
        private InvoiceInstallmentRecordService $service,
    ) {}

    /**
     * @inheritDoc
     */
    public function process(Request $request): Response
    {
        $id = $request->getRouteParam('id') ?? throw new BadRequest();
        $searchParams = $this->searchParamsFetcher->fetch($request);

        $invoice = $this->getInvoice($id);

        $collection = $this->service->getInstallments($invoice, $searchParams);

        return ResponseComposer::json([
            'list' => $collection->getValueMapList(),
            'total' => $collection->getTotal(),
        ]);
    }

    /**
     * @throws Forbidden
     * @throws NotFound
     */
    private function getInvoice(string $id): Invoice
    {
        $entity = $this->entityManager
            ->getRDBRepositoryByClass(Invoice::class)
            ->getById($id);

        if (!$entity) {
            throw new NotFound();
        }

        if (!$this->acl->checkEntityRead($entity)) {
            throw new Forbidden();
        }

        return $entity;
    }
}
