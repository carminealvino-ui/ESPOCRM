<?php
/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2026 EspoCRM, Inc.
 *
 * License ID: 57ae281c1f382ecc62c9ba36ed7b2350
 ************************************************************************************/

namespace Espo\Modules\Google\People;

class PhoneNumber
{
    private string $number;
    private ?string $type;

    private $typeMap = [
        'Mobile' => 'mobile',
        'Office' => 'work',
        'Home' => 'home',
        'Fax'  => 'fax',
        'Other' => 'other',
    ];

    private $defaultType = 'Other';

    public function __construct(string $number, ?string $type = null)
    {
        $this->number = $number;
        $this->type = $type;
    }

    public static function create(string $number, ?string $type = null): self
    {
        return new self($number, $type);
    }

    public function getNumber(): ?string
    {
        return $this->number;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function getGoogleType(): string
    {
        return
            $this->typeMap[$this->getType() ?? $this->defaultType] ??
            $this->typeMap[$this->defaultType];
    }
}
